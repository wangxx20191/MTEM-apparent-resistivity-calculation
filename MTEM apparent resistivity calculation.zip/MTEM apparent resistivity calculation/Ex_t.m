 function y=Ex_t(x)
global r;
global cos_fi;
global t_temp;
global ex_temp;
global I;
global DL;
miu=4*pi*10^-7;  %
tmp_h =sqrt(miu*r^2./(x.*t_temp));
tmp_h1 =tmp_h./sqrt(2);
 y=I*DL*(x/(2.0*pi*r^3.0))*((1+3*cos(2*acos(cos_fi)))/2.0-erf(0.5*sqrt(miu*r^2/(x*t_temp)))+(sqrt(miu*r^2/(x*t_temp))/(sqrt(pi)))*exp(-0.25*(miu*r^2/(x*t_temp))))-ex_temp;
