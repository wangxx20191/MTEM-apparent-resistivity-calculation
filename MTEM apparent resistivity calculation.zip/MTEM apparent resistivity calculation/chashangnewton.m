function N=chashangnewton(x,y,xi) 
n=length(x);
A=zeros(n);
Z=1.00000000000000; 
A(:,1)=y; 
N=A(1,1);
for k=2:n 
 for i=k:n
    A(i,k)=(A(i-1,k-1)-A(i,k-1))/(x(i+1-k)-x(i)); 
 end
Z=Z*(xi-x(k-1));
N=N+Z*A(k,k);
end
