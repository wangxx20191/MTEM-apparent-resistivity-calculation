%MTEM apparent resistivity calculation program,------Ex
%by wangxianxiang
%2019/1/19
clc;
clear all;
tic;
global r;              %Offset
global t_temp;         %Temporary time
global ex_temp;         %Temporary electric field value
global sin_fi;          %Receive angle sine
global cos_fi;          %Receive angle cosine
global I;               %source current amplitude
global DL;              %source length
I=1;
DL=1;
cos_fi =1;                 %Receive angle cosine
sin_fi = 0;                %eceive angle sine
miu=4.0*pi*10^-7;                %Magnetic permeability
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Data entry begins
DATA=load('2500.dat')'; 

fid2=fopen('2500-shi.dat','w');  %Output data file name

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%End of file input
NF=10;   %Number of measuring points
NT=3199;   %Data for each exploration point
for ii=1:NF;  
  t(1:NT)=DATA(3,(ii-1)*NT+1:(ii-1)*NT+NT);  %Read time 
  Ex(1:NT)=abs(DATA(4,(ii-1)*NT+1:(ii-1)*NT+NT));   %Reading electric field data
  r1=DATA(1,(ii-1)*NT+1);          %Read record
  r=DATA(2,(ii-1)*NT+1);          %Read offset
  P21=1;   % %Surface resistivity��Measurement data of early time is missing  and Surface resistivity is replaced by sounding data���� %abs(.50000000000000*miu*r^2/(t(1)*lambertw(0,-992.20085376959424561524208214724*t(1)^4*Ex(1)^2*r^2/miu^2)))
 x1=log(t(NT-2:NT));
y1=log(Ex(NT-2:NT));
a=polyfit(x1,y1,1);
ab=t(NT)^(a(1)+1)*exp(real(a(2)))/(-a(1)-1) ; %-exp(a(1)*t(1)+a(2))/a(1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Calculate the step-on response
   for ll=1:NT-1 ;                                                       %ʱ�����
      xx=t(ll:NT) ;
      yy=Ex(ll:NT) ;
    s(ll) = trapz(xx,yy);    %Ex    trapz(xx,yy)+ab;
   end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Calculate the step-on response
  ezz1=s(1)+I*DL*(P21/(2.0*pi*r^3.0))*((1+3*cos(2*acos(cos_fi)))/2.0-erf(0.5*sqrt(miu*r^2/(P21*t(1))))+(sqrt(miu*r^2/(P21*t(1)))/(sqrt(pi)))*exp(-0.25*(miu*r^2/(P21*t(1))))); %Calculated constant
   for i=1:NT-1
    t_temp=t(i); 
    ex_temp=ezz1-s(i); %Calculate the step-off response
    q1_temp=10^-2;      % the Lower limit of Resistivity
    w1_temp=10^6;       %the upper limit of Resistivity
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Calculate Ex apparent resistivity%%%%%%%%%%%%%%%%%%%%%%%
   [q1 w1]=boundtwodivi_Ex(q1_temp,w1_temp);     %Calculating Apparent Resistivity by Dichotomy
    tt1_temp=ceil(50*(log10(w1)-log10(q1)));    %The choice of how much Newton's inverse interpolation data
    x1=logspace(log10(q1),log10(w1),tt1_temp);  %Newton inverse 
    y1=Ex_t(x1);                                %Newton inverse  
    P_Ex(i)=chashangnewton(y1,x1,0);            %Newton inverse 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Calculate Ex apparent resistivity%%%%%%%%%%%%%%%%%%%%%%%  
    count=fprintf(fid2,'%30.23f %30.23f %25.23f %25.23f %25.23f %25.23f \n',...
    [r1,r,t(i),ex_temp,P_Ex(i),Ex(i)]);              
   end
end
fclose(fid2);
 toc