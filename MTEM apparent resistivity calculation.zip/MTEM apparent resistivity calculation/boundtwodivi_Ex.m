function [q w]=boundtwodivi_Ex(a,b) 
eps=1.001; 
while((b/a)>eps)
    c=(a+b)/2; 
     y=Ex_t(c);   
    if(y*Ex_t(a)<0) b=c; 
    else a=c; 
    end    
end
q=a; 
w=b;  